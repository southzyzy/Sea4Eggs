#!/bin/bash
# Maintained by: Zhao Xiang Lim (developer@zxlim.xyz)

DOCKER_VOLUME_DIR="/opt/docker_volumes"
TACACS_LOG_DIR="${DOCKER_VOLUME_DIR}/aaa_server/var/log"

if [[ ${EUID} -ne 0 ]]; then
    echo "[!] Please execute the script with root privileges."
    exit 1
elif ! [[ -x "$(command -v docker)" ]]; then
    echo "[!] docker not installed. Please install using 'apt-get install docker'"
    exit 1
elif ! [[ -x "$(command -v docker-compose)" ]]; then
    echo "[!] docker-compose not installed. Please install using 'apt-get install docker-compose'"
    exit 1
fi

if ! [[ -f "./Dockerfile" ]]; then
    echo "[!] Dockerfile not found in current directory. Please check again."
    exit 1
elif ! [[ -f "./docker-compose.yml" ]]; then
    echo "[!] docker-compose.yml not found in current directory. Please check again."
    exit 1
elif ! [[ -f "./tac_plus.conf" ]]; then
    echo "[!] tac_plus.conf not found in current directory. Please check again."
    exit 1
fi

rm -rf ${TACACS_LOG_DIR}
mkdir -p ${TACACS_LOG_DIR}
touch ${TACACS_LOG_DIR}/tac_plus.acct

docker build --no-cache -t tacacs .
docker-compose up -d
